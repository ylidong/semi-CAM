# Run all unit tests in installed directory unitTests
# 
# Author: Renaud Gaujoux
# Creation: 26 Oct 2011
###############################################################################

pkgmaker::utest('package:CellMix', quiet=FALSE)
